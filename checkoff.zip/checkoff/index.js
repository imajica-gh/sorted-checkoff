//Basic start up structures for boilerplate
//ALC 30/07/2020

//require the just installed express app
var express = require('express');//then we call express
var app = express();//takes us to the root(/) URL

app.get('/', function (req, res) {//when we visit the root URL express will respond with 'Hello World'
  res.send('Checkoff reporting!');
});//the server is listening on port 3000 for connections

app.listen(3000, function () {
  console.log('Checkoff app listening on port 3000!')
});

